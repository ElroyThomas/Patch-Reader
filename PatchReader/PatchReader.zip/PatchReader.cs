﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PatchReader
{
    public partial class PatchReader : Form
    {
        public PatchReader()
        {
            InitializeComponent();
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            opnDlgFileReader = new OpenFileDialog()
            {
                InitialDirectory = @"C:\",
                Title = "Browse Files",

                CheckFileExists = true,
                CheckPathExists = true,

                DefaultExt = "patch",
                Filter = "patch files (*.patch)|*.patch",
                FilterIndex = 2,
                RestoreDirectory = true,

                ReadOnlyChecked = true,
                ShowReadOnly = true,
                Multiselect = true
            };

            if (opnDlgFileReader.ShowDialog() == DialogResult.OK)
            {
                lstFiles.Items.Clear();
                txtOutput.Clear();

                lstFiles.Items.Add(opnDlgFileReader.FileName);
                string line = opnDlgFileReader.FileName;
                var type = line.GetType();

                string result = ReadFile(line);
                
                if (!string.IsNullOrEmpty(result))
                {
                    txtOutput.Text = result;
                }
                else
                {
                    MessageBox.Show("File is Empty");
                }
            }
        }

        public static string ReadFile(string filePath)
        {
            StringBuilder files = new StringBuilder();

            try
            {
                using (StreamReader file = new StreamReader(filePath))
                {
                    int counter = 0;
                    string ln;
                    while ((ln = file.ReadLine()) != null)
                    {
                        if (ln.Contains("(working copy)"))
                        {
                            ln = ln.Replace("(working copy)", "").Replace("+++ ", "").Trim();
                            if (!files.ToString().Contains(ln))
                            {
                                files.AppendLine(ln);
                            }
                        }
                        counter++;
                    }
                    file.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return files.ToString();
        }

        public static string ReadFile1(string filePath)
        {
            StringBuilder files = new StringBuilder();

            try
            {
                using (StreamReader file = new StreamReader(filePath))
                {
                    int counter = 0;
                    string ln;
                    while ((ln = file.ReadLine()) != null)
                    {
                        files.AppendLine(ln);
                        counter++;
                    }
                    file.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return files.ToString();
        }
    }
}
